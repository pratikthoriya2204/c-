﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace its_my_life
{
    class its_my_class
    {
        public static SqlConnection con = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=D:\pratik_c#\its_my_life\its_my_life\its_my_data.mdf;Integrated Security=True;User Instance=True");
    }
}
