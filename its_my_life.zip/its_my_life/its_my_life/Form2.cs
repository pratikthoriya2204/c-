﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace its_my_life
{
    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        internal static void Open()
        {

        }
        
        private void Form2_Load(object sender, EventArgs e)
        {
            string sql1 = "select * from its_my_tab";
            SqlDataAdapter da1 = new SqlDataAdapter(sql1, its_my_class.con);
            DataTable dt1 = new DataTable();
            da1.Fill(dt1);
            dataGridView1.DataSource = dt1;
            
        }
    }
}
