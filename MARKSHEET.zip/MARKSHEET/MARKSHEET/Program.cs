﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MARKSHEET
{
    class A
    {
        public int m1, m2, m3, total, per;
        public string result, grade;
    }

    class B : A
    {
        public void get()
        {
            Console.Write("Enter marks 1:");
            m1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter marks 2:");
            m2 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter marks 3:");
            m3 = Convert.ToInt32(Console.ReadLine());
        }
    }

    class C : B
    {
        public void Result()
        {
            total = m1 + m2 + m3;

            if (m1 >= 40 && m2 >= 40 && m3 >= 40)
            {
                per = total / 3;

                result = "pass";

                if (per >= 70)
                {
                    grade = "Distingtion";
                }
                else if (per >= 60)
                {
                    grade = "First";
                }
                else if (per >= 50)
                {
                    grade = "Secound";
                }
                else
                {
                    grade = "pass";
                }
            }
            else
            {
                per = 0;
                result = "Fail";
                grade = "F";
            }

        }
    }

    class D : C
    {
        public void print()
        {
            Console.WriteLine("TOTAL OF ALL SUBJECT IS :" + total);
            Console.WriteLine("");
            Console.WriteLine("PERCENTAGE OF ALL SUBJECT IS :" + per);
            Console.WriteLine("YOUR GRADE IS  :" + grade);
            Console.WriteLine("YOUR FINAL RESULT IS  :" + result);


        }
    }


    internal class Program
    {
        static void Main(string[] args)
        {
            D DD = new D();

            DD.get();
            DD.Result();
            DD.print();
            Console.Read();
        }
    }
}
